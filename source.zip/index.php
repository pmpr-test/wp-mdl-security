<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d46f3d12f1             |
    |_______________________________________|
*/
 use Pmpr\Module\Security\Security; Security::symcgieuakksimmu();

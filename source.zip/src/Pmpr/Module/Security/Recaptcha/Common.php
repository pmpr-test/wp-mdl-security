<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705178fc545d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Security\Recaptcha; use Pmpr\Module\Security\Container; class Common extends Container { }

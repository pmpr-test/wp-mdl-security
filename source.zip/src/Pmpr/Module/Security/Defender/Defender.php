<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68a63e25627fb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Security\Defender; use Pmpr\Module\Security\Container; use Pmpr\Module\Security\Defender\Auth\Auth; use Pmpr\Module\Security\Defender\Config\Config; use Pmpr\Module\Security\Defender\Resource\Resource; class Defender extends Container { public function mameiwsayuyquoeq() { Auth::symcgieuakksimmu(); Config::symcgieuakksimmu(); Resource::symcgieuakksimmu(); } }

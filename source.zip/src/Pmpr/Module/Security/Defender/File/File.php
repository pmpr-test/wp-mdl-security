<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68a63d4f7bb20             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Security\Defender\File; use Pmpr\Module\Security\Container; class File extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse('file_mod_allowed', [$this, 'wgasyygogwqkacai'], 10, 2); } public function wgasyygogwqkacai($oqkgomucoyswikgk, $mgkceomocowocqyo = null) : bool { if ($oqkgomucoyswikgk && $mgkceomocowocqyo === 'capability_edit_themes' && $this->weysguygiseoukqw(Setting::uemcweegicmqgeos)) { $oqkgomucoyswikgk = false; } return $oqkgomucoyswikgk; } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             682fc6db4685c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Security\Defender\Resource; use Automattic\WooCommerce\Blocks\Registry\Container; class Resource extends Container { }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68a661c623171             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Security\Defender\Resource; use Pmpr\Module\Security\Container; class REST extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse('rest_url_prefix', [$this, 'awicaswiakicaawc'])->cecaguuoecmccuse('rest_endpoints', [$this, 'wecgqwwioiokuusu']); } public function wecgqwwioiokuusu($cmgygcokoycqmics) { if (isset($cmgygcokoycqmics['/wp/v2'])) { unset($cmgygcokoycqmics['/wp/v2']); } if (isset($cmgygcokoycqmics['/wp/v2/users'])) { unset($cmgygcokoycqmics['/wp/v2/users']); } if (isset($cmgygcokoycqmics['/wp/v2/users/(?P<id>[\\d]+)'])) { unset($cmgygcokoycqmics['/wp/v2/users/(?P<id>[\\d]+)']); } return $cmgygcokoycqmics; } public function awicaswiakicaawc($yuwymayicwwqiske) { $moyaaaascoeowegu = $this->weysguygiseoukqw(Setting::eckoqwieouuqeaqg); if ($moyaaaascoeowegu) { $yuwymayicwwqiske = $moyaaaascoeowegu; } return $yuwymayicwwqiske; } }

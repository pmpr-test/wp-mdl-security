<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             688b675a3aedb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Security\Defender\Auth; use Pmpr\Module\Security\Container; use WP_Error; class Auth extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse('rest_index', [$this, 'sgssqekoegamyuci']); $this->cecaguuoecmccuse('xmlrpc_enabled', [$this, 'guuwugycyuymyqym']); } public function sgssqekoegamyuci($keccaugmemegoimu) { return $this->caokeucsksukesyo()->euekiyuksecoccus()->gosmqcmmomkqwmis(__('Page not found', PR__MDL__PANEL), 404); } public function guuwugycyuymyqym($iqsymysgkgosmiys) { if ($iqsymysgkgosmiys && $this->weysguygiseoukqw(Setting::aqaoeccwqmmwqcuo, false)) { $iqsymysgkgosmiys = false; } return $iqsymysgkgosmiys; } }

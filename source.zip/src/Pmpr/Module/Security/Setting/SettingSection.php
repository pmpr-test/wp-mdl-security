<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc0b28afad             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Security\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Section; class SettingSection extends Section { public function ikcgmcycisiccyuc() { $this->setting = Setting::symcgieuakksimmu(); } }

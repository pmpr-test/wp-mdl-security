<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6800fbc9399f0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Security\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Security\Recaptcha\Setting as RecaptchaSetting; class Setting extends BaseClass { public function qiccuiwooiquycsg() { parent::qiccuiwooiquycsg(); $this->igiywquyccyiaucw(Constants::kekcgssiyagioocg, 50); } public function wyyuauosmqoeucmg() { $this->title = __('Security Setting', PR__MDL__SECURITY); $this->igiywquyccyiaucw(Constants::qsegwakiwaiyimyy, __('Security', PR__MDL__SECURITY)); } public function ykwqaukkycogooii() { parent::ykwqaukkycogooii(); $this->kwugkiaumqigagwm(); } public function kwugkiaumqigagwm() { RecaptchaSetting::symcgieuakksimmu(); } }

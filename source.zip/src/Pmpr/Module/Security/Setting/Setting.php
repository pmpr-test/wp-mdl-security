<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc0b28afad             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Security\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Security\Recaptcha\Setting as RecaptchaSetting; class Setting extends BaseClass { public function qiccuiwooiquycsg() { parent::qiccuiwooiquycsg(); $this->igiywquyccyiaucw(Constants::kekcgssiyagioocg, 50); } public function wyyuauosmqoeucmg() { $this->title = __("\x53\145\143\x75\162\x69\x74\171\40\123\x65\x74\164\x69\156\x67", PR__MDL__SECURITY); $this->igiywquyccyiaucw(Constants::qsegwakiwaiyimyy, __("\123\x65\143\165\x72\151\164\x79", PR__MDL__SECURITY)); } public function ykwqaukkycogooii() { parent::ykwqaukkycogooii(); $this->kwugkiaumqigagwm(); } public function kwugkiaumqigagwm() { RecaptchaSetting::symcgieuakksimmu(); } }

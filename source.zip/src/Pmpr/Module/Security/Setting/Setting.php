<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7bf3ad0c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Security\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; class Setting extends BaseClass { public function qiccuiwooiquycsg() { $this->id = $this->akuociswqmoigkas(); $this->igiywquyccyiaucw(Constants::kekcgssiyagioocg, 50); parent::qiccuiwooiquycsg(); } public function wyyuauosmqoeucmg() { $this->title = __("\123\145\143\165\162\x69\164\171\40\x53\145\x74\164\151\x6e\147", PR__MDL__SECURITY); $this->igiywquyccyiaucw(Constants::qsegwakiwaiyimyy, __("\123\145\x63\165\162\151\164\171", PR__MDL__SECURITY)); } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705db7f019f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Security; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\Security\Setting\Setting; abstract class Container extends BaseClass { }

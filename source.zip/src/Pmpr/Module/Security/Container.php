<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             688b66f17f79d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Security; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\Security\Setting\Setting; abstract class Container extends BaseClass { }
